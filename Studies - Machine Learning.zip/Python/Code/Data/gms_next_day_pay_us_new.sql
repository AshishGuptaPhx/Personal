/* This procedure will create Daily/weekly dispute related, business, demographic variables at merchant level in IDN and pass it to CAS
*
*    - Following views are referenced
*
*                            b_se_dispute
*                            t_se_char_curr_global
*                            b_se_sales_volume
*                            b_roc
*                            b_se_char
*                            b_se_debit_bal_monthly
*  call  udw_bvws.gms_next_day_pay_us(2015049,'W',0)
* --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
/* ======================================================================================= */
-- Change History A new procedure to create 22 variables as part if NDP initiative to create daily/weekly file
 --
-- DATE        DEVELOPER               REASON
-- 08/25/2014  vkolachu                                                                Phase-1 Initial implementation
-- 04/20/2015  sdepur				 Performance Tuning
-- 10/01/2015  Vinoth TR             Weighted Average variables getting rounded off issue at 2 decimals is avoided and retained decimals as per layout datatype. (3 or 4 decimals)

/* =======================================================================================*/

REPLACE PROCEDURE gms_next_day_pay_us
        (
        IN  v_julian_in         INTEGER,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
        IN  v_override_cd                    CHAR(1),
        IN  v_process_mnth_override1 INTEGER
        )
DYNAMIC RESULT SETS 1

SQL SECURITY OWNER

BEGIN

/********* Declare Variables **********/

DECLARE debug_message                           VARCHAR(255);
DECLARE v_process_begin                 DATE;
DECLARE v_process_end                   DATE;
DECLARE v_process_mnth_overchar                 VARCHAR(6);
DECLARE v_msgbuffer                     VARCHAR(256);
DECLARE v_debug_message                 VARCHAR(5000);
DECLARE v_process_mnth_override                 INTEGER;
DECLARE v_process_calc                  BIGINT;
DECLARE v_errormsg                      VARCHAR(500);
DECLARE v_process_dt                    DATE;
DECLARE v_process_dt_end                DATE;
DECLARE v_start_dt                              DATE;
DECLARE v_dt_1_mnth                             DATE;
DECLARE v_dt_2_mnth                             DATE;
DECLARE v_dt_3_mnth                             DATE;
DECLARE v_dt_4_mnth                             DATE;
DECLARE v_dt_5_mnth                             DATE;
DECLARE v_dt_6_mnth                             DATE;
DECLARE v_dt_7_mnth                             DATE;
DECLARE v_dt_8_mnth                             DATE;
DECLARE v_dt_9_mnth                             DATE;
DECLARE v_dt_10_mnth                            DATE;
DECLARE v_dt_11_mnth                            DATE;
DECLARE v_dt_12_mnth                            DATE;
DECLARE v_dt_24_mnth                            DATE;
DECLARE v_curr_mnth_frst                        DATE;
DECLARE v_temp_override_cd              CHAR(1);
DECLARE v_final_sql                     VARCHAR(4000);
DECLARE v_process_calc1                 DATE;
DECLARE v_i                             INTEGER;
DECLARE vt_max_se_dt                                DATE;
DECLARE vt_max_se_dt_12                DATE;
DECLARE v_min_se_dt                                 DATE;

/*********************************************************************************************/
/* DECLARE CURSOR FOR OUTPUT VARIABLES                                                       */
/*********************************************************************************************/

DECLARE cur1 CURSOR WITH RETURN ONLY TO CLIENT FOR s1;

/********Initialize Variables**************/

SET     v_start_dt                       = (SELECT       CAST(SYSLIB.idn_jtog(v_julian_in) AS DATE));
SET     v_dt_1_mnth                      = (SELECT       ADD_MONTHS(v_start_dt,-1));
SET     v_dt_2_mnth                      = (SELECT       ADD_MONTHS(v_start_dt,-2));
SET     v_dt_3_mnth                      = (SELECT       ADD_MONTHS(v_start_dt,-3));
SET     v_dt_4_mnth                      = (SELECT       ADD_MONTHS(v_start_dt,-4));
SET     v_dt_5_mnth                      = (SELECT       ADD_MONTHS(v_start_dt,-5));
SET     v_dt_6_mnth                      = (SELECT       ADD_MONTHS(v_start_dt,-6));
SET     v_dt_7_mnth                      = (SELECT       ADD_MONTHS(v_start_dt,-7));
SET     v_dt_8_mnth                      = (SELECT       ADD_MONTHS(v_start_dt,-8));
SET     v_dt_9_mnth                      = (SELECT       ADD_MONTHS(v_start_dt,-9));
SET     v_dt_10_mnth                     = (SELECT       ADD_MONTHS(v_start_dt,-10));
SET     v_dt_11_mnth                     = (SELECT       ADD_MONTHS(v_start_dt,-11));
SET     v_dt_12_mnth                     = (SELECT       ADD_MONTHS(v_start_dt,-12));
SET     v_dt_24_mnth                     = (SELECT       ADD_MONTHS(v_start_dt,-24));
SET     v_curr_mnth_frst                 = (SELECT       v_start_dt - (EXTRACT( DAY from v_start_dt))+1 );
SET     v_process_calc                   = v_start_dt;
SET     v_i = 1;

SEL UPPER(v_override_cd) into v_temp_override_cd;

SET     debug_message = sp_debug(CAST( CURRENT_TIMESTAMP(6)AS CHAR(21) )  ||  ' initial variables are assiigned');

/************** Volatile tables to pull base se10 data to calculate weekly submission variables   **************/

CREATE  VOLATILE SET TABLE vt_se10
,NO FALLBACK
,NO JOURNAL
,CHECKSUM = DEFAULT
,DEFAULT MERGEBLOCKRATIO
,NO LOG
                                (
                SE10                       BIGINT  NOT NULL
                )

PRIMARY INDEX ( se10 )
                ON      COMMIT PRESERVE ROWS;

Insert into vt_se10
                Select    se10 from t_se_char_curr_global   where country_cd='840' and source_id='S' group by se10

;

/***************************************************** Daily Process ***********************************************/

IF v_temp_override_cd ='D' THEN

/******************************** Volatile tables to calculate Daily Dispute Variables with 24 months dispute data***************************/

CREATE  VOLATILE SET TABLE vt_se_dispute
,NO FALLBACK
,NO JOURNAL
,CHECKSUM = DEFAULT
,DEFAULT MERGEBLOCKRATIO
,NO LOG
        (
                se10                 BIGINT,
                trans_dt                         DATE FORMAT 'YYYY-MM-DD',
                dispute_open_dt      DATE FORMAT 'YYYY-MM-DD' NOT NULL ,
                dispute_close_dt     DATE FORMAT 'YYYY-MM-DD',
                actual_disputed_amt  DECIMAL(17,2)

                )

PRIMARY INDEX ( se10)
                ON      COMMIT PRESERVE ROWS;

INSERT INTO vt_se_dispute
                (
                se10       ,
                trans_dt,
                dispute_open_dt            ,
                dispute_close_dt             ,
                actual_disputed_amt
                )

SELECT distinct

                a.se10   ,
                a.trans_dt,
                a.dispute_open_dt         ,
                a.dispute_close_dt         ,
                a.actual_disputed_amt

FROM b_se_dispute a
WHERE  a.dispute_open_dt between :v_dt_24_mnth and :v_START_DT
  and dispute_open_dt <= :v_start_dt                AND
                (dispute_close_dt > :v_start_dt OR
                dispute_close_dt IS NULL           OR
                dispute_open_dt > dispute_close_dt)
  ;

CREATE  VOLATILE SET TABLE vt_open_dispute
,NO FALLBACK
,NO JOURNAL
,CHECKSUM = DEFAULT
,DEFAULT MERGEBLOCKRATIO
,NO LOG
        (
                se10                                       BIGINT,
                tot_actual_disp_amt      DECIMAL(19,2),
                dispute_open_amt         DECIMAL(10,0),
                dispute_open_cnt          DECIMAL(6,0)
                )
PRIMARY INDEX (SE10)
                ON      COMMIT PRESERVE ROWS;

INSERT INTO vt_open_dispute
                (
                se10                                       ,
                tot_actual_disp_amt      ,
                dispute_open_cnt

                )
SELECT

                se10                                       ,
                COALESCE(SUM(a.actual_disputed_amt),0) as tot_actual_disp_amt,
                count(*) as dispute_open_cnt

FROM   vt_se_dispute a
                  group by se10

;

UPDATE vt_open_dispute
FROM   vt_open_dispute
SET         dispute_open_amt = (case when tot_actual_disp_amt >= -000000001   AND tot_actual_disp_amt <= +999999999 then round(tot_actual_disp_amt)
                                                                when tot_actual_disp_amt <  -000000001 then -000000001
                                                                when tot_actual_disp_amt > +999999999 then +999999999
                                                                END )
;

/****************************** volatile table with 3 Next day pay daily attributes **********************/

CREATE  VOLATILE SET TABLE vt_next_day_pay_dly
,NO FALLBACK
,NO JOURNAL
,CHECKSUM = DEFAULT
,DEFAULT MERGEBLOCKRATIO
,NO LOG
                (
                SE10                                BIGINT NOT NULL,
                WEIGHT_BUS_AMT                      DECIMAL(12,0),
                WEIGHT_CREDIT_AMT                       DECIMAL(12,0),
                WEIGHT_ADJ_AMT                      DECIMAL(12,0),
                WEIGHT_DBT_ROC_CNT                  DECIMAL(12,3),
                WEIGHT_DBT_SOC_CNT                  DECIMAL(11,3),
                WEIGHT_CRD_ROC_CNT                  DECIMAL(11,3),
                WEIGHT_CRD_SOC_CNT                  DECIMAL(14,3),
                LAST_6MNTH_DBT_SUB_AMT              DECIMAL(12,0),
                LAST_6MNTH_DBT_ROC_CNT              DECIMAL(10,0),
                LAST_6MNTH_AVG_TKT_SZE              DECIMAL(11,3),
                WEIGHT_DISP_AMT                     DECIMAL(8,0),
                WEIGHT_DISP_CNT                     DECIMAL(9,3),
                LAST_6Mnth_DISP_AMT                 DECIMAL(10,0),
                WEIGHT_DSP_GRS_RATIO                DECIMAL(5,4),
                DISPUTE_OPEN_AMT                    DECIMAL(10,0),
                DISPUTE_OPEN_CNT                    DECIMAL(6,0),
                MOD_TENURE                          DECIMAL(5,0),
                MNTH_SINCE_LAST_SUB                 DECIMAL(5,0),
                SE_CHAIN_TYP                        CHAR(1),
                COUNTRY_CD                          DECIMAL(3,0),
                tooc_bus_vol_12mth                  DECIMAL(12,0),
                CURR_DEBIT_BAL_AMT                  DECIMAL(10,0)
                )
PRIMARY INDEX (se10)
                ON COMMIT PRESERVE ROWS;

INSERT INTO vt_next_day_pay_dly
                (
                SE10       ,
                WEIGHT_BUS_AMT        ,
                WEIGHT_CREDIT_AMT  ,
                WEIGHT_ADJ_AMT         ,
                WEIGHT_DBT_ROC_CNT              ,
                WEIGHT_DBT_SOC_CNT               ,
                WEIGHT_CRD_ROC_CNT              ,
                WEIGHT_CRD_SOC_CNT              ,
                LAST_6MNTH_DBT_SUB_AMT  ,
                LAST_6MNTH_DBT_ROC_CNT   ,
                LAST_6MNTH_AVG_TKT_SZE     ,
                WEIGHT_DISP_AMT       ,
                WEIGHT_DISP_CNT        ,
                LAST_6Mnth_DISP_AMT              ,
                WEIGHT_DSP_GRS_RATIO          ,
                DISPUTE_OPEN_AMT    ,
                DISPUTE_OPEN_CNT     ,
                MOD_TENURE  ,
                MNTH_SINCE_LAST_SUB             ,
                SE_CHAIN_TYP ,
                COUNTRY_CD    ,
                tooc_bus_vol_12mth     ,
                CURR_DEBIT_BAL_AMT
                )
SELECT
                a.se10,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                COALESCE(b.dispute_open_amt,0)     ,
                COALESCE(b.dispute_open_cnt,0)       ,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL

FROM  vt_se10 a,  vt_open_dispute b where a.se10 = b.se10  ;

-- Select to cursor

SET v_final_sql = 'SELECT

                SE10                                       ,
                WEIGHT_BUS_AMT                        ,
                WEIGHT_CREDIT_AMT  ,
                WEIGHT_ADJ_AMT                         ,
                WEIGHT_DBT_ROC_CNT              ,
                WEIGHT_DBT_SOC_CNT               ,
                WEIGHT_CRD_ROC_CNT              ,
                WEIGHT_CRD_SOC_CNT              ,
                LAST_6MNTH_DBT_SUB_AMT  ,
                LAST_6MNTH_DBT_ROC_CNT   ,
                LAST_6MNTH_AVG_TKT_SZE     ,
                WEIGHT_DISP_AMT                       ,
                WEIGHT_DISP_CNT                        ,
                LAST_6Mnth_DISP_AMT              ,
                WEIGHT_DSP_GRS_RATIO          ,
                DISPUTE_OPEN_AMT    ,
                DISPUTE_OPEN_CNT     ,
                MOD_TENURE                  ,
                MNTH_SINCE_LAST_SUB             ,
                SE_CHAIN_TYP                 ,
                COUNTRY_CD                    ,
                tooc_bus_vol_12mth     ,
                CURR_DEBIT_BAL_AMT
                FROM vt_next_day_pay_dly' ;

PREPARE s1 FROM v_final_sql;
OPEN cur1;
DEALLOCATE PREPARE s1;

END IF;

/***************************************************************** WEEKLY PROCESS ***************************************************************/

IF v_temp_override_cd ='W' THEN

/************** Volatile tables to pull merchant level data and calculate weekly submission variables   **************/

--To get the one years data from se_sales_volume from the maximun se_dt available in the table

 SELECT max(se_dt) from b_se_sales_volume where se_dt <= :v_start_dt  into vt_max_se_dt;

 SELECT add_months(:vt_max_se_dt, -11) into vt_max_se_dt_12 ;

CREATE  VOLATILE SET TABLE vt_se_sales_volume
,NO FALLBACK
,NO JOURNAL
,CHECKSUM = DEFAULT
,DEFAULT MERGEBLOCKRATIO
,NO LOG
        (
                SE10       BIGINT,
                bus_vol_usd DECIMAL(15,2) NOT NULL,
                ADJ_AMT_USD                 DECIMAL(14,2),
                SE_DT                                   DATE
                )

PRIMARY INDEX (SE10)
                ON      COMMIT PRESERVE ROWS;

INSERT INTO vt_se_sales_volume
                (
                SE10,
                bus_vol_usd ,
                ADJ_AMT_USD,
                SE_DT
                )
SELECT

                SE10,
                bus_vol_usd ,
                ADJ_AMT_USD,
                SE_DT

FROM b_se_sales_volume
Where se_dt between  :vt_max_se_dt_12  and  :vt_max_se_dt;

SET v_process_mnth_override = COALESCE(v_process_mnth_override1,0);

/************** Volatile tables to pull merchant level data from roc table and calculate Weighted business amount   **************/

CREATE  VOLATILE SET TABLE vt_se_roc1
,NO FALLBACK
,NO JOURNAL
,CHECKSUM = DEFAULT
,DEFAULT MERGEBLOCKRATIO
,NO LOG
        (
        SE10                                               BIGINT,
                BUS_VOL_1                        DECIMAL(17,2),
                BUS_VOL_2                        DECIMAL(17,2),
                BUS_VOL_3                        DECIMAL(17,2),
                BUS_VOL_4                        DECIMAL(17,2),
                BUS_VOL_5                        DECIMAL(17,2),
                BUS_VOL_6                        DECIMAL(17,2),
                BUS_VOL_7                        DECIMAL(17,2),
                BUS_VOL_8                        DECIMAL(17,2),
                BUS_VOL_9                        DECIMAL(17,2),
                BUS_VOL_10                     DECIMAL(17,2),
                BUS_VOL_11                     DECIMAL(17,2),
                BUS_VOL_12                     DECIMAL(17,2),
                NUMERATOR                     DECIMAL(20,5),
                WEIGHT_BUS_AMT                        DECIMAL(12,0)
                )
PRIMARY INDEX (SE10 )
        ON      COMMIT PRESERVE ROWS;

INSERT  INTO vt_se_roc1
        (
        se10  ,
        BUS_VOL_1,
        BUS_VOL_2,
        BUS_VOL_3,
        BUS_VOL_4,
        BUS_VOL_5,
        BUS_VOL_6,
        BUS_VOL_7,
        BUS_VOL_8,
        BUS_VOL_9,
        BUS_VOL_10,
        BUS_VOL_11,
        BUS_VOL_12
        )

SELECT
        a.se10                    ,
        COALESCE(SUM(case when aggr_mnth  > :v_dt_1_mnth and aggr_mnth <= :v_start_dt   Then  credit_amt_usd + debit_amt_usd  end),0)  as BUS_VOL_1,                    
                COALESCE(SUM(case when aggr_mnth  > :v_dt_2_mnth and aggr_mnth <= :v_dt_1_mnth  Then  credit_amt_usd + debit_amt_usd   end),0) as BUS_VOL_2,
                COALESCE(SUM(case when aggr_mnth  > :v_dt_3_mnth and aggr_mnth <= :v_dt_2_mnth  Then  credit_amt_usd + debit_amt_usd  end),0) as BUS_VOL_3,
                COALESCE(SUM(case when aggr_mnth  > :v_dt_4_mnth and aggr_mnth <= :v_dt_3_mnth  Then  credit_amt_usd + debit_amt_usd   end),0) as BUS_VOL_4,
                COALESCE(SUM(case when aggr_mnth  > :v_dt_5_mnth and aggr_mnth <= :v_dt_4_mnth  Then  credit_amt_usd + debit_amt_usd   end),0) as BUS_VOL_5,
                COALESCE(SUM(case when aggr_mnth  > :v_dt_6_mnth and aggr_mnth <= :v_dt_5_mnth  Then  credit_amt_usd + debit_amt_usd   end),0) as BUS_VOL_6,
                COALESCE(SUM(case when aggr_mnth  > :v_dt_7_mnth and aggr_mnth <= :v_dt_6_mnth  Then  credit_amt_usd + debit_amt_usd   end),0) as BUS_VOL_7,
                COALESCE(SUM(case when aggr_mnth  > :v_dt_8_mnth and aggr_mnth <= :v_dt_7_mnth  Then  credit_amt_usd + debit_amt_usd   end),0) as BUS_VOL_8,
                COALESCE(SUM(case when aggr_mnth  > :v_dt_9_mnth and aggr_mnth <= :v_dt_8_mnth  Then  credit_amt_usd + debit_amt_usd   end) ,0)as BUS_VOL_9,
                COALESCE(SUM(case when aggr_mnth  > :v_dt_10_mnth and aggr_mnth <= :v_dt_9_mnth  Then  credit_amt_usd + debit_amt_usd   end),0) as BUS_VOL_10,
                COALESCE(SUM(case when aggr_mnth  > :v_dt_11_mnth and aggr_mnth <= :v_dt_10_mnth  Then  credit_amt_usd + debit_amt_usd   end),0) as BUS_VOL_11,
                COALESCE(SUM(case when aggr_mnth  > :v_dt_12_mnth and aggr_mnth <= :v_dt_11_mnth  Then  credit_amt_usd + debit_amt_usd   end),0) as BUS_VOL_12
FROM   vt_se10 a left join b_gms_ndp_roc_aggr_mnth b on a.se10=b.se10 and us_intl_flg = 'US'
                group by a.se10

        ;

Update vt_se_roc1
                FROM vt_se_roc1
SET         NUMERATOR     = ((BUS_VOL_1 *1) +(BUS_VOL_2 *0.71)  +(BUS_VOL_3 *0.58)+(BUS_VOL_4 *0.50)+(BUS_VOL_5 *0.45)+(BUS_VOL_6 *0.41)+(BUS_VOL_7 *0.38)+(BUS_VOL_8 *0.35)+(BUS_VOL_9 *0.33)+(BUS_VOL_10 *0.32)+(BUS_VOL_11 *0.30)+(BUS_VOL_12 *0.29))

                ;

Update vt_se_roc1
                FROM vt_se_roc1
SET         WEIGHT_BUS_AMT        = (Case when (ROUND(NUMERATOR/5.61)) >= -99999999999  AND (ROUND(NUMERATOR/5.61)) <= +99999999999 Then (ROUND(NUMERATOR/5.61))
                                                                when (ROUND(NUMERATOR/5.61)) < -99999999999 then -99999999999
                                                                when  (ROUND(NUMERATOR/5.61))  > +99999999999 then +99999999999
                                                  END )
;

/************** Volatile tables to pull merchant level data from roc table and calculate Weighted Credit amount   **************/

CREATE  VOLATILE SET TABLE vt_se_roc2
,NO FALLBACK
,NO JOURNAL
,CHECKSUM = DEFAULT
,DEFAULT MERGEBLOCKRATIO
,NO LOG
        (
        SE10                                               BIGINT,
                CREDIT_VOL_1                  DECIMAL(17,2),
                CREDIT_VOL_2                  DECIMAL(17,2),
                CREDIT_VOL_3                  DECIMAL(17,2),
                CREDIT_VOL_4                  DECIMAL(17,2),
                CREDIT_VOL_5                  DECIMAL(17,2),
                CREDIT_VOL_6                  DECIMAL(17,2),
                CREDIT_VOL_7                  DECIMAL(17,2),
                CREDIT_VOL_8                  DECIMAL(17,2),
                CREDIT_VOL_9                  DECIMAL(17,2),
                CREDIT_VOL_10                DECIMAL(17,2),
                CREDIT_VOL_11                DECIMAL(17,2),
                CREDIT_VOL_12                DECIMAL(17,2),
                NUMERATOR                     DECIMAL(20,5),
                WEIGHT_CREDIT_AMT  DECIMAL(12,0)
                )
PRIMARY INDEX (SE10 )
        ON      COMMIT PRESERVE ROWS;

INSERT  INTO vt_se_roc2
        (
        se10  ,
        CREDIT_VOL_1,
        CREDIT_VOL_2,
        CREDIT_VOL_3,
        CREDIT_VOL_4,
        CREDIT_VOL_5,
        CREDIT_VOL_6,
        CREDIT_VOL_7,
        CREDIT_VOL_8,
        CREDIT_VOL_9,
        CREDIT_VOL_10,
        CREDIT_VOL_11,
        CREDIT_VOL_12
        )

SELECT
        se10                    ,
        COALESCE(SUM(case when aggr_mnth  > :v_dt_1_mnth and aggr_mnth <= :v_start_dt   Then  credit_amt_usd  end),0)  as CREDIT_VOL_1,                                 
                COALESCE(SUM(case when aggr_mnth  > :v_dt_2_mnth and aggr_mnth <= :v_dt_1_mnth  Then  credit_amt_usd   end),0) as CREDIT_VOL_2,
                COALESCE(SUM(case when aggr_mnth  > :v_dt_3_mnth and aggr_mnth <= :v_dt_2_mnth  Then  credit_amt_usd  end) ,0) as CREDIT_VOL_3,
                COALESCE(SUM(case when aggr_mnth  > :v_dt_4_mnth and aggr_mnth <= :v_dt_3_mnth  Then  credit_amt_usd   end),0) as CREDIT_VOL_4,
                COALESCE(SUM(case when aggr_mnth  > :v_dt_5_mnth and aggr_mnth <= :v_dt_4_mnth  Then  credit_amt_usd   end),0) as CREDIT_VOL_5,
                COALESCE(SUM(case when aggr_mnth  > :v_dt_6_mnth and aggr_mnth <= :v_dt_5_mnth  Then  credit_amt_usd   end),0) as CREDIT_VOL_6,
                COALESCE(SUM(case when aggr_mnth  > :v_dt_7_mnth and aggr_mnth <= :v_dt_6_mnth  Then  credit_amt_usd   end),0) as CREDIT_VOL_7,
                COALESCE(SUM(case when aggr_mnth  > :v_dt_8_mnth and aggr_mnth <= :v_dt_7_mnth  Then  credit_amt_usd   end),0) as CREDIT_VOL_8,
                COALESCE(SUM(case when aggr_mnth  > :v_dt_9_mnth and aggr_mnth <= :v_dt_8_mnth Then  credit_amt_usd   end),0) as CREDIT_VOL_9,
                COALESCE(SUM(case when aggr_mnth  > :v_dt_10_mnth and aggr_mnth <= :v_dt_9_mnth  Then  credit_amt_usd   end) ,0) as CREDIT_VOL_10,
                COALESCE(SUM(case when aggr_mnth  > :v_dt_11_mnth and aggr_mnth <= :v_dt_10_mnth  Then  credit_amt_usd   end),0) as CREDIT_VOL_11,
                COALESCE(SUM(case when aggr_mnth  > :v_dt_12_mnth and aggr_mnth <= :v_dt_11_mnth  Then  credit_amt_usd   end),0) as CREDIT_VOL_12

FROM   b_gms_ndp_roc_aggr_mnth WHERE us_intl_flg = 'US'
                group by se10

        ;

Update vt_se_roc2
                FROM vt_se_roc2
SET         NUMERATOR     = ((CREDIT_VOL_1 *1) +(CREDIT_VOL_2 *0.71)  +(CREDIT_VOL_3 *0.58)+(CREDIT_VOL_4 *0.50)+(CREDIT_VOL_5 *0.45)+(CREDIT_VOL_6 *0.41)+(CREDIT_VOL_7 *0.38)+(CREDIT_VOL_8 *0.35)+(CREDIT_VOL_9 *0.33)+(CREDIT_VOL_10 *0.32)+(CREDIT_VOL_11 *0.30)+(CREDIT_VOL_12 *0.29))

;

Update vt_se_roc2
                FROM vt_se_roc2
SET         WEIGHT_CREDIT_AMT = (Case when (ROUND(NUMERATOR/5.61)) >= -99999999999  AND (ROUND(NUMERATOR/5.61)) <= +00000000100 Then (ROUND(NUMERATOR/5.61))
                                                                when (ROUND(NUMERATOR/5.61)) < -99999999999 then -99999999999
                                                                when  (ROUND(NUMERATOR/5.61))  > +00000000100 then +00000000100
                                                                END )
;

/************** Volatile tables to pull merchant level data from roc table and calculate Weighted Adjustment amount   **************/

CREATE  VOLATILE SET TABLE vt_se_adj_amt
,NO FALLBACK
,NO JOURNAL
,CHECKSUM = DEFAULT
,DEFAULT MERGEBLOCKRATIO
,NO LOG
        (
        SE10                                               BIGINT,
                ADJ_VOL_1                        DECIMAL(17,2),
                ADJ_VOL_2                        DECIMAL(17,2),
                ADJ_VOL_3                        DECIMAL(17,2),
                ADJ_VOL_4                        DECIMAL(17,2),
                ADJ_VOL_5                        DECIMAL(17,2),
                ADJ_VOL_6                        DECIMAL(17,2),
                ADJ_VOL_7                        DECIMAL(17,2),
                ADJ_VOL_8                        DECIMAL(17,2),
                ADJ_VOL_9                        DECIMAL(17,2),
                ADJ_VOL_10                      DECIMAL(17,2),
                ADJ_VOL_11                      DECIMAL(17,2),
                ADJ_VOL_12                      DECIMAL(17,2),
                NUMERATOR                     DECIMAL(20,5),
                WEIGHT_ADJ_AMT                         DECIMAL(12,0)
                )
PRIMARY INDEX (SE10 )
        ON      COMMIT PRESERVE ROWS;

INSERT  INTO vt_se_adj_amt
        (
        se10  ,
        ADJ_VOL_1,
        ADJ_VOL_2,
        ADJ_VOL_3,
        ADJ_VOL_4,
        ADJ_VOL_5,
        ADJ_VOL_6,
        ADJ_VOL_7,
        ADJ_VOL_8,
        ADJ_VOL_9,
        ADJ_VOL_10,
        ADJ_VOL_11,
        ADJ_VOL_12
        )

SELECT
        se10                    ,
        COALESCE(SUM(case when SE_DT  > :v_dt_1_mnth and SE_DT <=  :v_start_dt   Then   COALESCE(ADJ_AMT_USD,0)  end),0)  as ADJ_VOL_1,                                 
                COALESCE(SUM(case when SE_DT >  :v_dt_2_mnth and SE_DT <=  :v_dt_1_mnth  Then  COALESCE(ADJ_AMT_USD,0)   end),0) as ADJ_VOL_2,
                COALESCE(SUM(case when SE_DT >  :v_dt_3_mnth and SE_DT <=  :v_dt_2_mnth  Then   COALESCE(ADJ_AMT_USD,0)  end),0) as ADJ_VOL_3,
                COALESCE(SUM(case when SE_DT >  :v_dt_4_mnth and SE_DT <=  :v_dt_3_mnth  Then   COALESCE(ADJ_AMT_USD,0)  end),0) as ADJ_VOL_4,
                COALESCE(SUM(case when SE_DT >  :v_dt_5_mnth and SE_DT <=  :v_dt_4_mnth  Then   COALESCE(ADJ_AMT_USD,0)  end),0) as ADJ_VOL_5,
                COALESCE(SUM(case when SE_DT >  :v_dt_6_mnth and SE_DT <=  :v_dt_5_mnth  Then   COALESCE(ADJ_AMT_USD,0)  end),0) as ADJ_VOL_6,
                COALESCE(SUM(case when SE_DT >  :v_dt_7_mnth and SE_DT <=  :v_dt_6_mnth  Then   COALESCE(ADJ_AMT_USD,0)  end),0) as ADJ_VOL_7,
                COALESCE(SUM(case when SE_DT >  :v_dt_8_mnth and SE_DT <=  :v_dt_7_mnth  Then   COALESCE(ADJ_AMT_USD,0)  end),0) as ADJ_VOL_8,
                COALESCE(SUM(case when SE_DT >  :v_dt_9_mnth and SE_DT <=  :v_dt_8_mnth  Then   COALESCE(ADJ_AMT_USD,0)  end),0) as ADJ_VOL_9,
                COALESCE(SUM(case when SE_DT >  :v_dt_10_mnth and SE_DT <=  :v_dt_9_mnth  Then   COALESCE(ADJ_AMT_USD,0)  end),0) as ADJ_VOL_10,
                COALESCE(SUM(case when SE_DT >  :v_dt_11_mnth and SE_DT <=  :v_dt_10_mnth Then   COALESCE(ADJ_AMT_USD,0)  end),0) as ADJ_VOL_11,
                COALESCE(SUM(case when SE_DT >  :v_dt_12_mnth and SE_DT <=  :v_dt_11_mnth  Then   COALESCE(ADJ_AMT_USD,0)  end),0) as ADJ_VOL_12
FROM   vt_se_sales_volume
                where ADJ_AMT_USD < 0
                group by se10

        ;

Update vt_se_adj_amt
                FROM vt_se_adj_amt
SET         NUMERATOR     = ((ADJ_VOL_1 *1) +(ADJ_VOL_2 *0.71)  +(ADJ_VOL_3 *0.58)+(ADJ_VOL_4 *0.50)+(ADJ_VOL_5 *0.45)+(ADJ_VOL_6 *0.41)+(ADJ_VOL_7 *0.38)+(ADJ_VOL_8 *0.35)+(ADJ_VOL_9 *0.33)+(ADJ_VOL_10 *0.32)+(ADJ_VOL_11 *0.30)+(ADJ_VOL_12 *0.29))

;

Update vt_se_adj_amt
                FROM vt_se_adj_amt
SET         WEIGHT_ADJ_AMT         = (Case when (ROUND(NUMERATOR/5.61)) >= -99999999999  AND (ROUND(NUMERATOR/5.61)) <= +99999999999 Then (ROUND(NUMERATOR/5.61))
                                                                when (ROUND(NUMERATOR/5.61)) < -99999999999 then -99999999999
                                                                when  (ROUND(NUMERATOR/5.61))  > +99999999999 then +99999999999
                                                  END )

;

/************** Volatile tables to pull merchant level data from roc table and calculate Weighted Debit ROC count   **************/

CREATE  VOLATILE SET TABLE vt_se_roc4
,NO FALLBACK
,NO JOURNAL
,CHECKSUM = DEFAULT
,DEFAULT MERGEBLOCKRATIO
,NO LOG
        (
        SE10                                               BIGINT,
                DRRCCT_1                           DECIMAL(17,2),
                DRRCCT_2                           DECIMAL(17,2),
                DRRCCT_3                           DECIMAL(17,2),
                DRRCCT_4                           DECIMAL(17,2),
                DRRCCT_5                           DECIMAL(17,2),
                DRRCCT_6                           DECIMAL(17,2),
                DRRCCT_7                           DECIMAL(17,2),
                DRRCCT_8                           DECIMAL(17,2),
                DRRCCT_9                           DECIMAL(17,2),
                DRRCCT_10                         DECIMAL(17,2),
                DRRCCT_11                         DECIMAL(17,2),
                DRRCCT_12                         DECIMAL(17,2),
                NUMERATOR                     DECIMAL(20,5),
                WEIGHT_DBT_ROC_CNT              DECIMAL(12,3)
                )
PRIMARY INDEX (SE10)
        ON      COMMIT PRESERVE ROWS;

INSERT  INTO vt_se_roc4
        (
        se10  ,
        DRRCCT_1,
        DRRCCT_2,
        DRRCCT_3,
        DRRCCT_4,
        DRRCCT_5,
        DRRCCT_6,
        DRRCCT_7,
        DRRCCT_8,
        DRRCCT_9,
        DRRCCT_10,
        DRRCCT_11,
        DRRCCT_12
        )

SELECT
    se10 ,
    COALESCE(SUM(case when aggr_mnth   > :v_dt_1_mnth and aggr_mnth <= :v_start_dt   Then  debit_cnt end),0)  as DRRCCT_1,                                              
                COALESCE(SUM(case when aggr_mnth   > :v_dt_2_mnth and aggr_mnth <= :v_dt_1_mnth  Then  debit_cnt  end),0) as DRRCCT_2,
                COALESCE(SUM(case when aggr_mnth   > :v_dt_3_mnth and aggr_mnth <= :v_dt_2_mnth  Then  debit_cnt end),0) as DRRCCT_3,
                COALESCE(SUM(case when aggr_mnth   > :v_dt_4_mnth and aggr_mnth <= :v_dt_3_mnth Then  debit_cnt end),0) as DRRCCT_4,
                COALESCE(SUM(case when aggr_mnth   > :v_dt_5_mnth and aggr_mnth <= :v_dt_4_mnth  Then  debit_cnt end),0) as DRRCCT_5,
                COALESCE(SUM(case when aggr_mnth   > :v_dt_6_mnth and aggr_mnth <= :v_dt_5_mnth  Then  debit_cnt end),0) as DRRCCT_6,
                COALESCE(SUM(case when aggr_mnth   > :v_dt_7_mnth and aggr_mnth <= :v_dt_6_mnth  Then  debit_cnt end),0) as DRRCCT_7,
                COALESCE(SUM(case when aggr_mnth   > :v_dt_8_mnth and aggr_mnth <= :v_dt_7_mnth  Then  debit_cnt end),0) as DRRCCT_8,
                COALESCE(SUM(case when aggr_mnth   > :v_dt_9_mnth and aggr_mnth <= :v_dt_8_mnth  Then  debit_cnt end) ,0)as DRRCCT_9,
                COALESCE(SUM(case when aggr_mnth   > :v_dt_10_mnth and aggr_mnth <= :v_dt_9_mnth  Then  debit_cnt end),0) as DRRCCT_10,
                COALESCE(SUM(case when aggr_mnth   > :v_dt_11_mnth and aggr_mnth <= :v_dt_10_mnth  Then debit_cnt end),0) as DRRCCT_11,
                COALESCE(SUM(case when aggr_mnth   > :v_dt_12_mnth and aggr_mnth <= :v_dt_11_mnth  Then debit_cnt end),0) as DRRCCT_12
FROM   b_gms_ndp_roc_aggr_mnth WHERE us_intl_flg = 'US'
                group by se10

        ;

Update vt_se_roc4
                FROM vt_se_roc4
SET         NUMERATOR     = ((DRRCCT_1 *1) +(DRRCCT_2 *0.71)  +(DRRCCT_3 *0.58)+(DRRCCT_4 *0.50)+(DRRCCT_5 *0.45)+(DRRCCT_6 *0.41)+(DRRCCT_7 *0.38)+(DRRCCT_8 *0.35)+(DRRCCT_9 *0.33)+(DRRCCT_10 *0.32)+(DRRCCT_11 *0.30)+(DRRCCT_12 *0.29))
                ;

Update vt_se_roc4
                FROM vt_se_roc4
SET         WEIGHT_DBT_ROC_CNT = (Case when (NUMERATOR/5.61) >= -00000001.000   AND (NUMERATOR/5.61) <= +99999999.000 Then (NUMERATOR/5.61)
                                                                when (NUMERATOR/5.61) < -00000001.000  then -00000001.000
                                                                when  (NUMERATOR/5.61)  > +99999999.000 then +99999999.000
                                                                END )
;

/************** Volatile tables to pull merchant level data from roc table and calculate Weighted Debit SOC count   **************/

CREATE  VOLATILE SET TABLE vt_se_roc5
,NO FALLBACK
,NO JOURNAL
,CHECKSUM = DEFAULT
,DEFAULT MERGEBLOCKRATIO
,NO LOG
        (
        SE10                                               BIGINT,
                DRSCCT_1                           DECIMAL(17,2),
                DRSCCT_2                           DECIMAL(17,2),
                DRSCCT_3                           DECIMAL(17,2),
                DRSCCT_4                           DECIMAL(17,2),
                DRSCCT_5                           DECIMAL(17,2),
                DRSCCT_6                           DECIMAL(17,2),
                DRSCCT_7                           DECIMAL(17,2),
                DRSCCT_8                           DECIMAL(17,2),
                DRSCCT_9                           DECIMAL(17,2),
                DRSCCT_10                         DECIMAL(17,2),
                DRSCCT_11                         DECIMAL(17,2),
                DRSCCT_12                         DECIMAL(17,2),
                NUMERATOR                     DECIMAL(20,5),
                WEIGHT_DBT_SOC_CNT               DECIMAL(11,3)
                )
PRIMARY INDEX (SE10)
        ON      COMMIT PRESERVE ROWS;

INSERT  INTO vt_se_roc5
        (
        se10  ,
        DRSCCT_1,
        DRSCCT_2,
        DRSCCT_3,
        DRSCCT_4,
        DRSCCT_5,
        DRSCCT_6,
        DRSCCT_7,
        DRSCCT_8,
        DRSCCT_9,
        DRSCCT_10,
        DRSCCT_11,
        DRSCCT_12
        )

SELECT distinct
        se10 ,
        COALESCE(SUM(case when sum_amt_usd >0 and process_dt > :v_dt_1_mnth and process_dt <= :v_start_dt    then 1 else 0 end),0)  as DRSCCT_1,                        
                COALESCE(SUM(case when sum_amt_usd >0 and process_dt > :v_dt_2_mnth and process_dt <= :v_dt_1_mnth    then 1 else 0 end),0)  as DRSCCT_2,
                COALESCE(SUM(case when sum_amt_usd >0 and process_dt > :v_dt_3_mnth and process_dt <= :v_dt_2_mnth    then 1 else 0 end),0)  as DRSCCT_3,
                COALESCE(SUM(case when sum_amt_usd >0 and process_dt > :v_dt_4_mnth and process_dt <= :v_dt_3_mnth    then 1 else 0 end),0)  as DRSCCT_4,
                COALESCE(SUM(case when sum_amt_usd >0 and process_dt > :v_dt_5_mnth and process_dt <= :v_dt_4_mnth    then 1 else 0 end),0)  as DRSCCT_5,
                COALESCE(SUM(case when sum_amt_usd >0 and process_dt > :v_dt_6_mnth and process_dt <= :v_dt_5_mnth    then 1 else 0 end),0)  as DRSCCT_6,
                COALESCE(SUM(case when sum_amt_usd >0 and process_dt > :v_dt_7_mnth and process_dt <= :v_dt_6_mnth    then 1 else 0 end),0)  as DRSCCT_7,
                COALESCE(SUM(case when sum_amt_usd >0 and process_dt > :v_dt_8_mnth and process_dt <= :v_dt_7_mnth    then 1 else 0 end),0)  as DRSCCT_8,
                COALESCE(SUM(case when sum_amt_usd >0 and process_dt > :v_dt_9_mnth and process_dt <= :v_dt_8_mnth    then 1 else 0 end),0) as DRSCCT_9,
                COALESCE(SUM(case when sum_amt_usd >0 and process_dt > :v_dt_10_mnth and process_dt <= :v_dt_9_mnth    then 1 else 0 end),0)  as DRSCCT_10,
                COALESCE(SUM(case when sum_amt_usd >0 and process_dt > :v_dt_11_mnth and process_dt <= :v_dt_10_mnth    then 1 else 0 end),0)  as DRSCCT_11,
                COALESCE(SUM(case when sum_amt_usd >0 and process_dt > :v_dt_12_mnth and process_dt <= :v_dt_11_mnth    then 1 else 0 end),0)  as DRSCCT_12
FROM   b_gms_ndp_roc_sum_tble WHERE us_intl_flg = 'US'
                group by se10

        ;

Update vt_se_roc5
                FROM vt_se_roc5
SET         NUMERATOR     = ((DRSCCT_1 *1) +(DRSCCT_2 *0.71)  +(DRSCCT_3 *0.58)+(DRSCCT_4 *0.50)+(DRSCCT_5 *0.45)+(DRSCCT_6 *0.41)+(DRSCCT_7 *0.38)+(DRSCCT_8 *0.35)+(DRSCCT_9 *0.33)+(DRSCCT_10 *0.32)+(DRSCCT_11 *0.30)+(DRSCCT_12 *0.29))
;

Update vt_se_roc5
                FROM vt_se_roc5
SET         WEIGHT_DBT_SOC_CNT = (Case when (NUMERATOR/5.61) >= -0000001.000    AND (NUMERATOR/5.61) <= +9999999.000 Then (NUMERATOR/5.61)
                                                                when (NUMERATOR/5.61) < -0000001.000   then -0000001.000
                                                                when  (NUMERATOR/5.61)  > +9999999.000 then +9999999.000
                                                                END )

;

/************** Volatile tables to pull merchant level data from roc table and calculate Weighted Credit SOC count   **************/

CREATE  VOLATILE SET TABLE vt_se_roc6
,NO FALLBACK
,NO JOURNAL
,CHECKSUM = DEFAULT
,DEFAULT MERGEBLOCKRATIO
,NO LOG
        (
                SE10                                       BIGINT,
                CRSCCT_1                            DECIMAL(17,2),
                CRSCCT_2                            DECIMAL(17,2),
                CRSCCT_3                            DECIMAL(17,2),
                CRSCCT_4                            DECIMAL(17,2),
                CRSCCT_5                            DECIMAL(17,2),
                CRSCCT_6                            DECIMAL(17,2),
                CRSCCT_7                            DECIMAL(17,2),
                CRSCCT_8                            DECIMAL(17,2),
                CRSCCT_9                            DECIMAL(17,2),
                CRSCCT_10                         DECIMAL(17,2),
                CRSCCT_11                         DECIMAL(17,2),
                CRSCCT_12                         DECIMAL(17,2),
                NUMERATOR                     DECIMAL(20,5),
                WEIGHT_CRD_SOC_CNT              DECIMAL(14,3)
                )
PRIMARY INDEX (SE10 )
        ON      COMMIT PRESERVE ROWS;

INSERT  INTO vt_se_roc6
        (
        se10  ,
        CRSCCT_1,
        CRSCCT_2,
        CRSCCT_3,
        CRSCCT_4,
        CRSCCT_5,
        CRSCCT_6,
        CRSCCT_7,
        CRSCCT_8,
        CRSCCT_9,
        CRSCCT_10,
        CRSCCT_11,
        CRSCCT_12
        )

SELECT  distinct
        se10 ,
        COALESCE(SUM(case when sum_amt_usd <0 and process_dt > :v_dt_1_mnth and process_dt <= :v_start_dt    then 1 else 0 end),0)  as CRSCCT_1,                        
                COALESCE(SUM(case when sum_amt_usd <0 and process_dt > :v_dt_2_mnth and process_dt <= :v_dt_1_mnth    then 1 else 0 end),0)  as CRSCCT_2,
                COALESCE(SUM(case when sum_amt_usd <0 and process_dt > :v_dt_3_mnth and process_dt <= :v_dt_2_mnth    then 1 else 0 end),0)  as CRSCCT_3,
                COALESCE(SUM(case when sum_amt_usd <0 and process_dt > :v_dt_4_mnth and process_dt <= :v_dt_3_mnth    then 1 else 0 end),0)  as CRSCCT_4,
                COALESCE(SUM(case when sum_amt_usd <0 and process_dt > :v_dt_5_mnth and process_dt <= :v_dt_4_mnth    then 1 else 0 end),0)  as CRSCCT_5,
                COALESCE(SUM(case when sum_amt_usd <0 and process_dt > :v_dt_6_mnth and process_dt <= :v_dt_5_mnth    then 1 else 0 end),0)  as CRSCCT_6,
                COALESCE(SUM(case when sum_amt_usd <0 and process_dt > :v_dt_7_mnth and process_dt <= :v_dt_6_mnth    then 1 else 0 end),0)  as CRSCCT_7,
                COALESCE(SUM(case when sum_amt_usd <0 and process_dt > :v_dt_8_mnth and process_dt <= :v_dt_7_mnth    then 1 else 0 end),0)  as CRSCCT_8,
                COALESCE(SUM(case when sum_amt_usd <0 and process_dt > :v_dt_9_mnth and process_dt <= :v_dt_8_mnth    then 1 else 0 end),0) as CRSCCT_9,
                COALESCE(SUM(case when sum_amt_usd <0 and process_dt > :v_dt_10_mnth and process_dt <= :v_dt_9_mnth    then 1 else 0 end),0)  as CRSCCT_10,
                COALESCE(SUM(case when sum_amt_usd <0 and process_dt > :v_dt_11_mnth and process_dt <= :v_dt_10_mnth    then 1 else 0 end),0)  as CRSCCT_11,
                COALESCE(SUM(case when sum_amt_usd <0 and process_dt > :v_dt_12_mnth and process_dt <= :v_dt_11_mnth    then 1 else 0 end),0)  as CRSCCT_12
FROM   b_gms_ndp_roc_sum_tble WHERE us_intl_flg = 'US'
                group by se10

        ;

Update vt_se_roc6
                FROM vt_se_roc6
SET         NUMERATOR     = ((CRSCCT_1 *1) +(CRSCCT_2 *0.71)  +(CRSCCT_3 *0.58)+(CRSCCT_4 *0.50)+(CRSCCT_5 *0.45)+(CRSCCT_6 *0.41)+(CRSCCT_7 *0.38)+(CRSCCT_8 *0.35)+(CRSCCT_9 *0.33)+(CRSCCT_10 *0.32)+(CRSCCT_11 *0.30)+(CRSCCT_12 *0.29))

;

Update vt_se_roc6
                FROM vt_se_roc6
SET         WEIGHT_CRD_SOC_CNT = (Case when (NUMERATOR/5.61) >= -000001.000     AND (NUMERATOR/5.61) <= +999999.000 Then (NUMERATOR/5.61)
                                                                when (NUMERATOR/5.61) < -000001.000    then -000001.000
                                                                when  (NUMERATOR/5.61)  > +999999.000 then +999999.000
                                                                END )

;

/************** Volatile tables to pull merchant level data from roc table and calculate Weighted Credit ROC count   **************/

CREATE  VOLATILE SET TABLE vt_se_roc7
,NO FALLBACK
,NO JOURNAL
,CHECKSUM = DEFAULT
,DEFAULT MERGEBLOCKRATIO
,NO LOG
        (
        SE10                                               BIGINT,
                CRRCCT_1                           DECIMAL(17,2),
                CRRCCT_2                           DECIMAL(17,2),
                CRRCCT_3                           DECIMAL(17,2),
                CRRCCT_4                           DECIMAL(17,2),
                CRRCCT_5                           DECIMAL(17,2),
                CRRCCT_6                           DECIMAL(17,2),
                CRRCCT_7                           DECIMAL(17,2),
                CRRCCT_8                           DECIMAL(17,2),
                CRRCCT_9                           DECIMAL(17,2),
                CRRCCT_10                         DECIMAL(17,2),
                CRRCCT_11                         DECIMAL(17,2),
                CRRCCT_12                         DECIMAL(17,2),
                NUMERATOR                     DECIMAL(20,5),
                WEIGHT_CRD_ROC_CNT              DECIMAL(11,3)
                )
PRIMARY INDEX (SE10 )
        ON      COMMIT PRESERVE ROWS;

INSERT  INTO vt_se_roc7
        (
        se10  ,
                CRRCCT_1,
        CRRCCT_2,
        CRRCCT_3,
        CRRCCT_4,
        CRRCCT_5,
        CRRCCT_6,
        CRRCCT_7,
        CRRCCT_8,
        CRRCCT_9,
        CRRCCT_10,
        CRRCCT_11,
        CRRCCT_12
        )

SELECT
        se10 ,
        COALESCE(SUM(case when aggr_mnth   > :v_dt_1_mnth and aggr_mnth <= :v_start_dt   Then  credit_cnt end),0)  as CRRCCT_1,                                         
                COALESCE(SUM(case when aggr_mnth   > :v_dt_2_mnth and aggr_mnth <= :v_dt_1_mnth  Then credit_cnt  end),0) as CRRCCT_2,
                COALESCE(SUM(case when aggr_mnth   > :v_dt_3_mnth and aggr_mnth <= :v_dt_2_mnth  Then  credit_cnt end),0) as CRRCCT_3,
                COALESCE(SUM(case when aggr_mnth   > :v_dt_4_mnth and aggr_mnth <= :v_dt_3_mnth  Then  credit_cnt end),0) as CRRCCT_4,
                COALESCE(SUM(case when aggr_mnth   > :v_dt_5_mnth and aggr_mnth <= :v_dt_4_mnth  Then  credit_cnt end),0) as CRRCCT_5,
                COALESCE(SUM(case when aggr_mnth   > :v_dt_6_mnth and aggr_mnth <= :v_dt_5_mnth  Then  credit_cnt end),0) as CRRCCT_6,
                COALESCE(SUM(case when aggr_mnth   > :v_dt_7_mnth and aggr_mnth <= :v_dt_6_mnth  Then  credit_cnt end),0) as CRRCCT_7,
                COALESCE(SUM(case when aggr_mnth   > :v_dt_8_mnth and aggr_mnth <= :v_dt_7_mnth  Then  credit_cnt end),0) as CRRCCT_8,
                COALESCE(SUM(case when aggr_mnth   > :v_dt_9_mnth and aggr_mnth <= :v_dt_8_mnth  Then  credit_cnt end) ,0)as CRRCCT_9,
                COALESCE(SUM(case when aggr_mnth   > :v_dt_10_mnth and aggr_mnth <= :v_dt_9_mnth  Then  credit_cnt end),0) as CRRCCT_10,
                COALESCE(SUM(case when aggr_mnth   > :v_dt_11_mnth and aggr_mnth <= :v_dt_10_mnth  Then  credit_cnt end),0) as CRRCCT_11,
                COALESCE(SUM(case when aggr_mnth   > :v_dt_12_mnth and aggr_mnth <= :v_dt_11_mnth  Then credit_cnt end),0) as CRRCCT_12
FROM   b_gms_ndp_roc_aggr_mnth  WHERE us_intl_flg = 'US'
                group by se10

        ;

Update vt_se_roc7
                FROM vt_se_roc7
SET         NUMERATOR     = ((CRRCCT_1 *1) +(CRRCCT_2 *0.71)  +(CRRCCT_3 *0.58)+(CRRCCT_4 *0.50)+(CRRCCT_5 *0.45)+(CRRCCT_6 *0.41)+(CRRCCT_7 *0.38)+(CRRCCT_8 *0.35)+(CRRCCT_9 *0.33)+(CRRCCT_10 *0.32)+(CRRCCT_11 *0.30)+(CRRCCT_12 *0.29))

;

Update vt_se_roc7
                FROM vt_se_roc7
SET         WEIGHT_CRD_ROC_CNT = (Case when (NUMERATOR/5.61) >= -0000001.000      AND (NUMERATOR/5.61) <= +9999999.000 Then (NUMERATOR/5.61)
                                                                when (NUMERATOR/5.61) < -0000001.000     then -0000001.000
                                                                when  (NUMERATOR/5.61)  > +9999999.000 then +9999999.000
                                                                END )
;

/************** Volatile tables calculate Last 6 month debit submission amount,Last 6 month debit roc count and Average ticket size last 6 month  **************/

CREATE  VOLATILE SET TABLE vt_se_roc81
,NO FALLBACK
,NO JOURNAL
,CHECKSUM = DEFAULT
,DEFAULT MERGEBLOCKRATIO
,NO LOG
        (
        SE10                                               BIGINT,
                TOT_CHARGE_AMT_USD             DECIMAL(14,2),
                CHARGE_AMT_USD_cnt              DECIMAL(10,0),
                LAST_6MNTH_DBT_SUB_AMT  DECIMAL(17,5), 
                LAST_6MNTH_DBT_ROC_CNT   DECIMAL(10,0),
                LAST_6MNTH_AVG_TKT_SZE     DECIMAL(11,3)
                )
PRIMARY INDEX (SE10)
        ON      COMMIT PRESERVE ROWS;

INSERT  INTO vt_se_roc81
        (
        se10                    ,
        TOT_CHARGE_AMT_USD     ,
                CHARGE_AMT_USD_cnt
        )

SELECT
        se10                    ,
        COALESCE( ROUND(SUM(DEBIT_AMT_USD)),0)                        ,
                COALESCE(SUM(DEBIT_CNT),0)
FROM   b_gms_ndp_roc_aggr_mnth WHERE us_intl_flg = 'US' AND
                aggr_mnth > :v_dt_6_mnth  and aggr_mnth <= :v_start_dt
                group by se10

        ;

Update vt_se_roc81
SET       LAST_6MNTH_DBT_SUB_AMT = case when (TOT_CHARGE_AMT_USD >= -00000000001  AND TOT_CHARGE_AMT_USD <= +99999999999) then TOT_CHARGE_AMT_USD
                                                                                          when (TOT_CHARGE_AMT_USD < -00000000001 ) then -00000000001
                                                                                          when (TOT_CHARGE_AMT_USD > +99999999999 ) then +99999999999
                                                                                                          END ,
                LAST_6MNTH_DBT_ROC_CNT =  case when (CHARGE_AMT_USD_CNT >= -000000001   AND CHARGE_AMT_USD_CNT<= +999999999) then CHARGE_AMT_USD_cnt
                                                                                          when (CHARGE_AMT_USD_CNT < -000000001  ) then -000000001
                                                                                          when (CHARGE_AMT_USD_CNT > +999999999 ) then +999999999
                                                                                                          END ;

Update vt_se_roc81
SET        LAST_6MNTH_AVG_TKT_SZE =     case  when (LAST_6MNTH_DBT_ROC_CNT <= 0) then -1
                                                                                    when (LAST_6MNTH_DBT_ROC_CNT > 0) then ( LAST_6MNTH_DBT_SUB_AMT / LAST_6MNTH_DBT_ROC_CNT )
                                                                                    END
;

-- Volatile tables to calculate minimum and maximum se_dt  for each se10 from vt_se_sales_volume for  tenure calculation

CREATE  VOLATILE SET TABLE vt_se_sales_vol_minmax_sedt
,NO FALLBACK
,NO JOURNAL
,CHECKSUM = DEFAULT
,DEFAULT MERGEBLOCKRATIO
,NO LOG
        (
                SE10                       BIGINT  NOT NULL,
                MIN_SEDT DATE FORMAT 'YYYY-MM-DD' NOT NULL,
                MAX_SEDT DATE FORMAT 'YYYY-MM-DD' NOT NULL
                )
PRIMARY INDEX (SE10)
                ON      COMMIT PRESERVE ROWS;

insert into vt_se_sales_vol_minmax_sedt (
SE10,
MIN_SEDT,
MAX_SEDT)

select se10,min(se_dt),max(se_dt) from b_se_sales_volume
where gross_amt_usd > 0 and se_dt <= :v_start_dt group by se10;

CREATE  VOLATILE SET TABLE vt_se_roc9
,NO FALLBACK
,NO JOURNAL
,CHECKSUM = DEFAULT
,DEFAULT MERGEBLOCKRATIO
,NO LOG
               (
                SE10                       BIGINT,
                MOD_TENURE  DECIMAL(5,0),
                MNTH_SINCE_LAST_SUB             DECIMAL(5,0)
                )
PRIMARY INDEX(SE10)
        ON      COMMIT PRESERVE ROWS;

INSERT INTO vt_se_roc9
                (
                SE10,
                MOD_TENURE,
                MNTH_SINCE_LAST_SUB
                )
SELECT  distinct
                se10,
                round(months_between(v_start_dt,min_sedt ),0)  as MOD_TENURE,
                round(months_between(v_start_dt,max_sedt),0) as MNTH_SINCE_LAST_SUB

FROM vt_se_sales_vol_minmax_sedt

;
/********************************* Inserting all the attributes calculated from ROC table into one vt table*************************/

CREATE  VOLATILE SET TABLE vt_se_roc_consolidate
,NO FALLBACK
,NO JOURNAL
,CHECKSUM = DEFAULT
,DEFAULT MERGEBLOCKRATIO
,NO LOG
        (
        SE10                                                               BIGINT,
                CHARGE_AMT_USD                                       DECIMAL(14,2),
                PROCESS_DT                                      DATE,
                WEIGHT_BUS_AMT                                        DECIMAL(12,0),
                WEIGHT_CREDIT_AMT                  DECIMAL(12,0),
                WEIGHT_ADJ_AMT                                         DECIMAL(12,0),
                WEIGHT_DBT_ROC_CNT                              DECIMAL(12,3),
                WEIGHT_DBT_SOC_CNT                               DECIMAL(11,3),
                WEIGHT_CRD_ROC_CNT                              DECIMAL(11,3),
                WEIGHT_CRD_SOC_CNT                              DECIMAL(14,3),
                LAST_6MNTH_DBT_SUB_AMT                  DECIMAL(12,0),
                LAST_6MNTH_DBT_ROC_CNT                   DECIMAL(10,0),
                LAST_6MNTH_AVG_TKT_SZE                     DECIMAL(11,3),
                MOD_TENURE                                  DECIMAL(5,0),
                MNTH_SINCE_LAST_SUB                             DECIMAL(5,0)
                )
PRIMARY INDEX (SE10 )
        ON      COMMIT PRESERVE ROWS;

INSERT INTO  vt_se_roc_consolidate
                (
                SE10,
                WEIGHT_BUS_AMT,
                WEIGHT_CREDIT_AMT,
                WEIGHT_ADJ_AMT,
                WEIGHT_DBT_ROC_CNT,
                WEIGHT_DBT_SOC_CNT,
                WEIGHT_CRD_ROC_CNT,
                WEIGHT_CRD_SOC_CNT,
                LAST_6MNTH_DBT_SUB_AMT,
                LAST_6MNTH_DBT_ROC_CNT,
                LAST_6MNTH_AVG_TKT_SZE,
                MOD_TENURE,
                MNTH_SINCE_LAST_SUB
                )

SELECT
                a.SE10,
                COALESCE(a.WEIGHT_BUS_AMT,0),
                COALESCE(b.WEIGHT_CREDIT_AMT,0),
                COALESCE(c.WEIGHT_ADJ_AMT,0),
                COALESCE(d.WEIGHT_DBT_ROC_CNT,0),
                COALESCE(e.WEIGHT_DBT_SOC_CNT,0),
                COALESCE(f.WEIGHT_CRD_ROC_CNT,0),
                COALESCE(g.WEIGHT_CRD_SOC_CNT,0),
                COALESCE(h.LAST_6MNTH_DBT_SUB_AMT,0),
                COALESCE(h.LAST_6MNTH_DBT_ROC_CNT,0),
                COALESCE(h.LAST_6MNTH_AVG_TKT_SZE,0),
                COALESCE((case when i.MOD_TENURE >= -0001  and i.MOD_TENURE < +9999 then i.MOD_TENURE
                                when i.MOD_TENURE < -0001 then -0001 when i.MOD_TENURE > +9999 then +9999 end), 0) as MOD_TENURE ,
                COALESCE((case when i.MNTH_SINCE_LAST_SUB >= -0001  and i.MNTH_SINCE_LAST_SUB < +9999 then i.MNTH_SINCE_LAST_SUB
                                when i.MNTH_SINCE_LAST_SUB < -0001 then -0001 when i.MNTH_SINCE_LAST_SUB > +9999 then +9999 end), 0) as MNTH_SINCE_LAST_SUB

FROM   vt_se_roc1 a                      left outer join    vt_se_roc2 b
                on a.se10 = b.se10           left outer join    vt_se_adj_amt c
                on a.se10 = c.se10           left outer join    vt_se_roc4 d
                on a.se10 = d.se10           left outer join    vt_se_roc5 e
                on a.se10 = e.se10           left outer join    vt_se_roc7 f
                on a.se10 = f.se10            left outer join    vt_se_roc6 g
                on a.se10 = g.se10           left outer join    vt_se_roc81 h
                on a.se10 = h.se10           left outer join    vt_se_roc9 i
                on a.se10 = i.se10

;

/******************************** VT tables to calculate the weekly dispute attributes ********************************************/

CREATE  VOLATILE SET TABLE vt_se_dispute
,NO FALLBACK
,NO JOURNAL
,CHECKSUM = DEFAULT
,DEFAULT MERGEBLOCKRATIO
,NO LOG
        (
                feed_key                            BIGINT NOT NULL,
                se10                                       BIGINT,
                trans_dt                               DATE FORMAT 'YYYY-MM-DD',
                cm11                                     BIGINT,
                trans_amt                           DECIMAL(15,2) ,
                dispute_open_dt                            DATE FORMAT 'YYYY-MM-DD' NOT NULL ,
                dispute_amt                      DECIMAL(15,2) NOT NULL,
                dispute_close_dt             DATE FORMAT 'YYYY-MM-DD',
                actual_disputed_amt     DECIMAL(17,2),
                dispute_case_id                               CHAR(15) CHARACTER SET LATIN NOT CASESPECIFIC NOT NULL
                )

PRIMARY INDEX ( se10 ,cm11 ,dispute_case_id )
                ON      COMMIT PRESERVE ROWS;

INSERT INTO vt_se_dispute
                (
                feed_key,
                se10       ,
                trans_dt               ,
                cm11,
                trans_amt           ,
                dispute_open_dt            ,
                dispute_amt      ,
                dispute_close_dt             ,
                actual_disputed_amt     ,
                dispute_case_id
                  )

SELECT distinct

                a.feed_key,
                a.se10   ,
                a.trans_dt           ,
                a.cm11,
                a.trans_amt       ,
                a.dispute_open_dt         ,
                a.dispute_amt  ,
                a.dispute_close_dt         ,
                a.actual_disputed_amt ,
                a.dispute_case_id

FROM b_se_dispute a
WHERE                 a.dispute_open_dt between :v_dt_12_mnth and :v_START_DT

;

-- To calculate Top rank record satisfying the below partition

create multiset volatile table vt_dispute_rnk1 as
(select a.*, rank() over (partition by se10, cm11,trans_dt, trans_amt order by dispute_open_dt desc) "toprec"
from vt_se_dispute  a
)
with data primary index(se10) on commit preserve rows ;

create multiset volatile table vt_se_dispute1 as
(select a.*
from vt_dispute_rnk1  a
where toprec = 1
) with data primary index(se10) on commit preserve rows ;

CREATE  VOLATILE SET TABLE vt_se_roc10
,NO FALLBACK
,NO JOURNAL
,CHECKSUM = DEFAULT
,DEFAULT MERGEBLOCKRATIO
,NO LOG
        (
        SE10                                               BIGINT,
                TOT_6Mnth_DISP_AMT               DECIMAL(17,2),
                DISPAMT_1                        DECIMAL(17,2),
                DISPAMT_2                        DECIMAL(17,2),
                DISPAMT_3                        DECIMAL(17,2),
                DISPAMT_4                        DECIMAL(17,2),
                DISPAMT_5                        DECIMAL(17,2),
                DISPAMT_6                        DECIMAL(17,2),
                DISPAMT_7                        DECIMAL(17,2),
                DISPAMT_8                        DECIMAL(17,2),
                DISPAMT_9                        DECIMAL(17,2),
                DISPAMT_10                      DECIMAL(17,2),
                DISPAMT_11                      DECIMAL(17,2),
                DISPAMT_12                      DECIMAL(17,2),
                NUMERATOR                     DECIMAL(20,5),
                WEIGHT_DISP_AMT                       DECIMAL(8,0),
                LAST_6Mnth_DISP_AMT              DECIMAL(10,0)
                )
PRIMARY INDEX (SE10 )
        ON      COMMIT PRESERVE ROWS;

INSERT  INTO vt_se_roc10
        (
        se10  ,
                TOT_6Mnth_DISP_AMT,
                DISPAMT_1,
        DISPAMT_2,
        DISPAMT_3,
        DISPAMT_4,
        DISPAMT_5,
        DISPAMT_6,
        DISPAMT_7,
        DISPAMT_8,
        DISPAMT_9,
        DISPAMT_10,
        DISPAMT_11,
        DISPAMT_12
        )

SELECT
        se10            ,
                ROUND(COALESCE(SUM(case when dispute_open_dt  > :v_dt_6_mnth and dispute_open_dt <= :v_start_dt  Then  actual_disputed_amt end),0)) as TOT_6Mnth_DISP_AMT,
                COALESCE(SUM(case when dispute_open_dt  > :v_dt_1_mnth and dispute_open_dt <= :v_start_dt     Then  actual_disputed_amt end),0)  as DISPAMT_1,          
                COALESCE(SUM(case when dispute_open_dt  > :v_dt_2_mnth and dispute_open_dt <= :v_dt_1_mnth  Then  actual_disputed_amt  end),0) as DISPAMT_2,
                COALESCE(SUM(case when dispute_open_dt  > :v_dt_3_mnth and dispute_open_dt <= :v_dt_2_mnth  Then  actual_disputed_amt end),0) as DISPAMT_3,
                COALESCE(SUM(case when dispute_open_dt  > :v_dt_4_mnth and dispute_open_dt <= :v_dt_3_mnth  Then  actual_disputed_amt  end),0) as DISPAMT_4,
                COALESCE(SUM(case when dispute_open_dt  > :v_dt_5_mnth and dispute_open_dt <= :v_dt_4_mnth  Then  actual_disputed_amt  end),0) as DISPAMT_5,
                COALESCE(SUM(case when dispute_open_dt  > :v_dt_6_mnth and dispute_open_dt <= :v_dt_5_mnth  Then  actual_disputed_amt  end),0) as DISPAMT_6,
                COALESCE(SUM(case when dispute_open_dt  > :v_dt_7_mnth and dispute_open_dt <= :v_dt_6_mnth  Then  actual_disputed_amt  end),0) as DISPAMT_7,
                COALESCE(SUM(case when dispute_open_dt  > :v_dt_8_mnth and dispute_open_dt <= :v_dt_7_mnth  Then  actual_disputed_amt  end),0) as DISPAMT_8,
                COALESCE(SUM(case when dispute_open_dt  > :v_dt_9_mnth and dispute_open_dt <= :v_dt_8_mnth  Then  actual_disputed_amt  end),0) as DISPAMT_9,
                COALESCE(SUM(case when dispute_open_dt  > :v_dt_10_mnth and dispute_open_dt <= :v_dt_9_mnth  Then  actual_disputed_amt  end),0) as DISPAMT_10,
                COALESCE(SUM(case when dispute_open_dt  > :v_dt_11_mnth and dispute_open_dt <= :v_dt_10_mnth  Then  actual_disputed_amt  end),0) as DISPAMT_11,
                COALESCE(SUM(case when dispute_open_dt  > :v_dt_12_mnth and dispute_open_dt <= :v_dt_11_mnth  Then  actual_disputed_amt  end),0) as DISPAMT_12

FROM   vt_se_dispute1
                group by se10
;

Update vt_se_roc10
                FROM vt_se_roc10
SET         NUMERATOR     = ((DISPAMT_1 *1) +(DISPAMT_2 *0.71)  +(DISPAMT_3 *0.58)+(DISPAMT_4 *0.50)+(DISPAMT_5 *0.45)+(DISPAMT_6 *0.41)+(DISPAMT_7 *0.38)+(DISPAMT_8 *0.35)+(DISPAMT_9 *0.33)+(DISPAMT_10 *0.32)+(DISPAMT_11 *0.30)+(DISPAMT_12 *0.29)),
                LAST_6Mnth_DISP_AMT = (Case when ROUND(TOT_6Mnth_DISP_AMT) >= -000000001        AND ROUND(TOT_6Mnth_DISP_AMT) <= +999999999  Then ROUND(TOT_6Mnth_DISP_AMT)
                                                                when ROUND(TOT_6Mnth_DISP_AMT)< -000000001       then -000000001
                                                                when  ROUND(TOT_6Mnth_DISP_AMT)> +999999999  then +999999999
                                                                END )
;

Update                 vt_se_roc10
                FROM vt_se_roc10
SET         WEIGHT_DISP_AMT       = (Case when ROUND(NUMERATOR/5.61) >= -0000000       AND ROUND(NUMERATOR/5.61) <= +9999999 Then ROUND(NUMERATOR/5.61)
                                                                when ROUND(NUMERATOR/5.61) < -0000000      then -0000000
                                                                when  ROUND(NUMERATOR/5.61)  > +9999999 then +9999999
                                                                END )
;

CREATE  VOLATILE SET TABLE vt_se_roc11
,NO FALLBACK
,NO JOURNAL
,CHECKSUM = DEFAULT
,DEFAULT MERGEBLOCKRATIO
,NO LOG
        (
        SE10                                               BIGINT,
                DISPCNT_1                         DECIMAL(17,2),
                DISPCNT_2                         DECIMAL(17,2),
                DISPCNT_3                         DECIMAL(17,2),
                DISPCNT_4                         DECIMAL(17,2),
                DISPCNT_5                         DECIMAL(17,2),
                DISPCNT_6                         DECIMAL(17,2),
                DISPCNT_7                         DECIMAL(17,2),
                DISPCNT_8                         DECIMAL(17,2),
                DISPCNT_9                         DECIMAL(17,2),
                DISPCNT_10                       DECIMAL(17,2),
                DISPCNT_11                       DECIMAL(17,2),
                DISPCNT_12                       DECIMAL(17,2),
                NUMERATOR                     DECIMAL(20,5),
                WEIGHT_DISP_CNT                        DECIMAL(9,3)
                )
PRIMARY INDEX (SE10 )
        ON      COMMIT PRESERVE ROWS;

INSERT  INTO vt_se_roc11
        (
        se10  ,
                DISPCNT_1,
        DISPCNT_2,
        DISPCNT_3,
        DISPCNT_4,
        DISPCNT_5,
        DISPCNT_6,
        DISPCNT_7,
        DISPCNT_8,
        DISPCNT_9,
        DISPCNT_10,
        DISPCNT_11,
        DISPCNT_12
        )

SELECT
        se10            ,
                COALESCE(SUM(case when dispute_open_dt > :v_dt_1_mnth and dispute_open_dt <= :v_start_dt      Then  1 end),0)  as DISPCNT_1,                            
                COALESCE(SUM(case when dispute_open_dt > :v_dt_2_mnth and dispute_open_dt <= :v_dt_1_mnth  Then  1  end),0) as DISPCNT_2,
                COALESCE(SUM(case when dispute_open_dt > :v_dt_3_mnth and dispute_open_dt <= :v_dt_2_mnth  Then  1 end),0) as DISPCNT_3,
                COALESCE(SUM(case when dispute_open_dt > :v_dt_4_mnth and dispute_open_dt <= :v_dt_3_mnth  Then  1  end),0) as DISPCNT_4,
                COALESCE(SUM(case when dispute_open_dt > :v_dt_5_mnth and dispute_open_dt <= :v_dt_4_mnth  Then  1  end),0) as DISPCNT_5,
                COALESCE(SUM(case when dispute_open_dt > :v_dt_6_mnth and dispute_open_dt <= :v_dt_5_mnth  Then  1  end),0) as DISPCNT_6,
                COALESCE(SUM(case when dispute_open_dt > :v_dt_7_mnth and dispute_open_dt <= :v_dt_6_mnth  Then  1  end),0) as DISPCNT_7,
                COALESCE(SUM(case when dispute_open_dt > :v_dt_8_mnth and dispute_open_dt <= :v_dt_7_mnth  Then  1  end),0) as DISPCNT_8,
                COALESCE(SUM(case when dispute_open_dt > :v_dt_9_mnth and dispute_open_dt <= :v_dt_8_mnth  Then  1  end),0) as DISPCNT_9,
                COALESCE(SUM(case when dispute_open_dt > :v_dt_10_mnth and dispute_open_dt <= :v_dt_9_mnth Then  1  end),0) as DISPCNT_10,
                COALESCE(SUM(case when dispute_open_dt > :v_dt_11_mnth and dispute_open_dt <= :v_dt_10_mnth  Then  1  end),0) as DISPCNT_11,
                COALESCE(SUM(case when dispute_open_dt > :v_dt_12_mnth and dispute_open_dt <= :v_dt_11_mnth  Then  1  end),0) as DISPCNT_12

FROM   vt_se_dispute1
                group by se10

;

Update vt_se_roc11
                FROM vt_se_roc11
SET         NUMERATOR     = ((DISPCNT_1 *1) +(DISPCNT_2 *0.71)  +(DISPCNT_3 *0.58)+(DISPCNT_4 *0.50)+(DISPCNT_5 *0.45)+(DISPCNT_6 *0.41)+(DISPCNT_7 *0.38)+(DISPCNT_8 *0.35)+(DISPCNT_9 *0.33)+(DISPCNT_10 *0.32)+(DISPCNT_11 *0.30)+(DISPCNT_12 *0.29))

;

Update vt_se_roc11
                FROM vt_se_roc11
SET         WEIGHT_DISP_CNT        = (Case when (NUMERATOR/5.61) >= -00001.000       AND (NUMERATOR/5.61) <= +99999.000 Then (NUMERATOR/5.61)
                                                                when (NUMERATOR/5.61) < -00001.000      then -00001.000
                                                                when  (NUMERATOR/5.61)  > +99999.000 then +99999.000
                                                                END )
;

/********************************** The variables calculated taking data from Dbo.se_char table *************************************/

CREATE  VOLATILE SET TABLE vt_se_roc12
,NO FALLBACK
,NO JOURNAL
,CHECKSUM = DEFAULT
,DEFAULT MERGEBLOCKRATIO
,NO LOG
        (
        SE10                                               BIGINT,
                SE_CHAIN_TYP                 CHAR(1),
                COUNTRY_CD                    CHAR(3)
                )
PRIMARY INDEX (SE10 )
        ON      COMMIT PRESERVE ROWS;

INSERT INTO vt_se_roc12
                (
                SE10                                       ,
                SE_CHAIN_TYP                 ,
                COUNTRY_CD
                )
SELECT  distinct

                SE10                                       ,
                SE_CHAIN_TYP                 ,
                case when substr(COUNTRY_CD,1,1) not in ('0','1','2','3','4','5','6','7','8','9') then '000'
                else COUNTRY_CD end as COUNTRY_CD

FROM   b_se_char
;

/********************************** The variables calculated by taking data from se_debit_bal_monthly table *************************************/

CREATE  VOLATILE SET TABLE vt_se_roc13
,NO FALLBACK
,NO JOURNAL
,CHECKSUM = DEFAULT
,DEFAULT MERGEBLOCKRATIO
,NO LOG
        (
        SE10                                               BIGINT,
        curr_debit_bal_amt       DECIMAL(10,0)
        )
PRIMARY INDEX (SE10 )
        ON      COMMIT PRESERVE ROWS;

INSERT INTO vt_se_roc13
                (
                SE10                                       ,
                curr_debit_bal_amt
                )

SELECT  distinct
                SE10,
                (case when ROUND(MAX(COALESCE(TOT_DEBIT_BAL_AMT,0))) >= -000000001  and ROUND(MAX(COALESCE(TOT_DEBIT_BAL_AMT,0))) <= +999999999 then ROUND(MAX(COALESCE(TOT_DEBIT_BAL_AMT,0)))
                                when ROUND(MAX(COALESCE(TOT_DEBIT_BAL_AMT,0))) > -000000001 then -000000001
                                when ROUND(MAX(COALESCE(TOT_DEBIT_BAL_AMT,0))) < +999999999 then +999999999
                end)as curr_debit_bal_amt

FROM b_se_debit_bal_monthly a
WHERE a.AS_OF_DT between :v_dt_1_mnth and :v_start_dt
                GROUP BY a.SE10
;

/********************************** To calculate Weighted dispute to gross ratio *************************************/

CREATE  VOLATILE SET TABLE vt_disp_gross_ratio
,NO FALLBACK
,NO JOURNAL
,CHECKSUM = DEFAULT
,DEFAULT MERGEBLOCKRATIO
,NO LOG
        (
        SE10                               BIGINT,
                DTG1                     DECIMAL(17,2),
                DTG2                     DECIMAL(17,2),
                DTG3                     DECIMAL(17,2),
                DTG4                     DECIMAL(17,2),
                DTG5                     DECIMAL(17,2),
                DTG6                     DECIMAL(17,2),
                DTG7                     DECIMAL(17,2),
                DTG8                     DECIMAL(17,2),
                DTG9                     DECIMAL(17,2),
                DTG10                   DECIMAL(17,2),
                DTG11                   DECIMAL(17,2),
                DTG12                   DECIMAL(17,2),
                NUMERATOR     DECIMAL(20,5),
                WEIGHT_DSP_GRS_RATIO          DECIMAL(5,4)
                )
PRIMARY INDEX (SE10 )
        ON      COMMIT PRESERVE ROWS;

INSERT  INTO vt_disp_gross_ratio
        (
        se10  ,
                DTG1,
        DTG2,
        DTG3,
        DTG4,
        DTG5,
        DTG6,
        DTG7,
        DTG8,
        DTG9,
        DTG10,
        DTG11,
        DTG12
        )

SELECT
                a.se10,
                (case when a.BUS_VOL_1 = 0 and COALESCE(b.DISPAMT_1,0) = 0   then 0 when a.BUS_VOL_1 = 0 and COALESCE(b.DISPAMT_1,0) < 0   then 0 when a.BUS_VOL_1 <= 0  and COALESCE(b.DISPAMT_1,0) > 0 then 1 else COALESCE((b.DISPAMT_1/a.BUS_VOL_1),0) end ) as DTG1,
                (case when a.BUS_VOL_2 = 0 and COALESCE(b.DISPAMT_2,0)  = 0 then 0 when a.BUS_VOL_2 = 0 and COALESCE(b.DISPAMT_2,0)  < 0 then 0 when a.BUS_VOL_2 <= 0 and COALESCE(b.DISPAMT_2,0)  > 0   then 1 else COALESCE((b.DISPAMT_2/a.BUS_VOL_2),0) end ) as DTG2,
                (case when a.BUS_VOL_3 = 0 and COALESCE(b.DISPAMT_3,0)  = 0 then 0 when a.BUS_VOL_3 = 0 and COALESCE(b.DISPAMT_3,0)  < 0 then 0 when a.BUS_VOL_3 <= 0 and COALESCE(b.DISPAMT_3,0)  > 0   then 1  else COALESCE((b.DISPAMT_3/a.BUS_VOL_3),0) end ) as DTG3,
                (case when a.BUS_VOL_4 = 0 and COALESCE(b.DISPAMT_4,0)  = 0 then 0 when a.BUS_VOL_4 = 0 and COALESCE(b.DISPAMT_4,0)  < 0 then 0 when a.BUS_VOL_4 <= 0 and COALESCE(b.DISPAMT_4,0)  > 0   then 1  else COALESCE((b.DISPAMT_4/a.BUS_VOL_4),0) end ) as DTG4,
                (case when a.BUS_VOL_5 = 0 and COALESCE(b.DISPAMT_5,0)  = 0 then 0 when a.BUS_VOL_5 = 0 and COALESCE(b.DISPAMT_5,0)  < 0 then 0 when a.BUS_VOL_5 <= 0 and COALESCE(b.DISPAMT_5,0)  > 0   then 1  else COALESCE((b.DISPAMT_5/a.BUS_VOL_5),0) end ) as DTG5,
                (case when a.BUS_VOL_6 = 0 and COALESCE(b.DISPAMT_6,0)  = 0 then 0 when a.BUS_VOL_6 = 0 and COALESCE(b.DISPAMT_6,0)  < 0 then 0 when  a.BUS_VOL_6 <= 0 and COALESCE(b.DISPAMT_6,0)  > 0   then 1  else COALESCE((b.DISPAMT_6/a.BUS_VOL_6),0) end ) as DTG6,
                (case when a.BUS_VOL_7 = 0 and COALESCE(b.DISPAMT_7,0)  = 0 then 0 when a.BUS_VOL_7 = 0 and COALESCE(b.DISPAMT_7,0)  < 0 then 0 when a.BUS_VOL_7 <= 0 and COALESCE(b.DISPAMT_7,0)  > 0   then 1   else COALESCE((b.DISPAMT_7/a.BUS_VOL_7),0) end ) as DTG7,
                (case when a.BUS_VOL_8 = 0 and COALESCE(b.DISPAMT_8,0)  = 0 then 0  when a.BUS_VOL_8 = 0 and COALESCE(b.DISPAMT_8,0) < 0 then 0 when a.BUS_VOL_8 <= 0 and COALESCE(b.DISPAMT_8,0)  > 0   then 1   else COALESCE((b.DISPAMT_8/a.BUS_VOL_8),0) end ) as DTG8,
                (case when a.BUS_VOL_9 = 0 and COALESCE(b.DISPAMT_9,0)  = 0 then 0 when a.BUS_VOL_9 = 0 and COALESCE(b.DISPAMT_9,0)  < 0 then 0 when a.BUS_VOL_9 <= 0 and COALESCE(b.DISPAMT_9,0)  > 0   then 1   else COALESCE((b.DISPAMT_9/a.BUS_VOL_9),0) end ) as DTG9,
                (case when a.BUS_VOL_10 = 0 and COALESCE(b.DISPAMT_10,0)  = 0 then 0 when a.BUS_VOL_10 = 0 and COALESCE(b.DISPAMT_10,0)  < 0 then 0 when a.BUS_VOL_10 <= 0 and COALESCE(b.DISPAMT_10,0)  > 0   then 1    else COALESCE((b.DISPAMT_10/a.BUS_VOL_10),0) end ) as DTG10,
                (case when a.BUS_VOL_11 = 0 and COALESCE(b.DISPAMT_11,0)  = 0 then 0 when a.BUS_VOL_11 = 0 and COALESCE(b.DISPAMT_11,0)  < 0 then 0 when a.BUS_VOL_11 <= 0 and COALESCE(b.DISPAMT_11,0)  > 0   then 1    else COALESCE((b.DISPAMT_11/a.BUS_VOL_11),0) end ) as DTG11,
                (case when a.BUS_VOL_12 = 0 and COALESCE(b.DISPAMT_12,0)  = 0 then 0 when a.BUS_VOL_12 = 0 and COALESCE(b.DISPAMT_12,0)  < 0 then 0 when a.BUS_VOL_12 <= 0 and COALESCE(b.DISPAMT_12,0)  > 0   then 1    else COALESCE((b.DISPAMT_12/a.BUS_VOL_12),0) end ) as DTG12

FROM   vt_se_roc1 a left outer join vt_se_roc10 b
                on           a.se10 = b.se10

;

Update vt_disp_gross_ratio
                FROM vt_disp_gross_ratio
SET       DTG1 = case when DTG1 > 1 then 1 else  DTG1 end,
                         DTG2 = case when DTG2 > 1 then 1 else  DTG2 end,
                         DTG3 = case when DTG3 > 1 then 1 else  DTG3 end,
                         DTG4 = case when DTG4 > 1 then 1 else  DTG4 end,
                         DTG5 = case when DTG5 > 1 then 1 else  DTG5 end,
                         DTG6 = case when DTG6 > 1 then 1 else  DTG6 end,
                         DTG7 = case when DTG7 > 1 then 1 else  DTG7 end,
                         DTG8 = case when DTG8 > 1 then 1 else  DTG8 end,
                         DTG9 = case when DTG9 > 1 then 1 else  DTG9 end,
                         DTG10 = case when DTG10 > 1 then 1 else  DTG10 end,
                         DTG11 = case when DTG11 > 1 then 1 else  DTG11 end,
                         DTG12 = case when DTG12 > 1 then 1 else  DTG12 end

                         ;

Update vt_disp_gross_ratio
                FROM vt_disp_gross_ratio
SET         NUMERATOR     = COALESCE(((DTG1 *1) +(DTG2 *0.71)  +(DTG3 *0.58)+(DTG4 *0.50)+(DTG5 *0.45)+(DTG6 *0.41)+(DTG7 *0.38)+(DTG8 *0.35)+(DTG9 *0.33)+(DTG10 *0.32)+(DTG11 *0.30)+(DTG12 *0.29)),0)

;

Update vt_disp_gross_ratio
                FROM vt_disp_gross_ratio
SET         WEIGHT_DSP_GRS_RATIO = (Case when (NUMERATOR/5.61) >= -1.0000        AND (NUMERATOR/5.61) <= +9.0000 Then (NUMERATOR/5.61)
                                                                when (NUMERATOR/5.61) < -1.0000       then -1.0000
                                                                when  (NUMERATOR/5.61)  > +9.0000 then +9.0000
                                                                END )
;

/*********************** Volatile tables to calculate Chain volumne ****************************************************/

/***************************** to have the distinct combination of SE10 and TOOC_GLC_SE10 of se10_tooc_mapping in a vt table **********************/

CREATE  VOLATILE  MULTISET TABLE vt_se10_toc_mapping
,NO FALLBACK
,NO JOURNAL
,CHECKSUM = DEFAULT
,DEFAULT MERGEBLOCKRATIO
,NO LOG
        (
                TOOC_GLB_SE10              BIGINT
                )
PRIMARY INDEX (TOOC_GLB_SE10)
                ON      COMMIT PRESERVE ROWS;

Insert into vt_se10_toc_mapping
                (
                tooc_glb_se10
                )
SELECT
                tooc_glb_se10

FROM  b_se10_toc_mapping a, vt_se10 b
where a.se10=b.se10
                group by TOOC_GLB_SE10               ;
                
                CREATE  VOLATILE MULTISET TABLE vt_tooc_othse10
,NO FALLBACK
,NO JOURNAL
,CHECKSUM = DEFAULT
,DEFAULT MERGEBLOCKRATIO
,NO LOG
        (
                SE10                       BIGINT  NOT NULL,
                TOOC_GLB_SE10              BIGINT
                )
PRIMARY INDEX(SE10,TOOC_GLB_SE10 )
                ON      COMMIT PRESERVE ROWS;

INSERT INTO vt_tooc_othse10
                (
                SE10,
                TOOC_GLB_SE10
                )

SELECT  a.se10, b.tooc_glb_se10 
FROM   b_se10_toc_mapping a, vt_se10_toc_mapping   b
WHERE a.tooc_glb_se10 = b.tooc_glb_se10 
                and a.tooc_glb_se10 not in (6316383017,1260246103,6317254050,1045136397,4102492154,1045727567,2291935831);

CREATE  VOLATILE MULTISET TABLE vt_chain_vol_consol
,NO FALLBACK
,NO JOURNAL
,CHECKSUM = DEFAULT
,DEFAULT MERGEBLOCKRATIO
,NO LOG
        (
                TOOC_GLB_SE10              BIGINT,
                tooc_bus_vol_12mth     DECIMAL(12,0) NOT NULL
                )
PRIMARY INDEX( TOOC_GLB_SE10)
                ON      COMMIT PRESERVE ROWS;

INSERT INTO vt_chain_vol_consol
                (
                TOOC_GLB_SE10,
                tooc_bus_vol_12mth
                )
SELECT  
                a.tooc_glb_se10, 
                COALESCE(SUM(c.bus_vol_usd),0) as tooc_bus_vol_12mth

FROM   vt_tooc_othse10 a 
                left outer join vt_se_sales_volume c
                on a.se10 = c.se10 where se_dt between   :vt_max_se_dt_12  and  :vt_max_se_dt  
                group by a.tooc_glb_se10                
            
;

CREATE  VOLATILE MULTISET TABLE vt_chain_vol
,NO FALLBACK
,NO JOURNAL
,CHECKSUM = DEFAULT
,DEFAULT MERGEBLOCKRATIO
,NO LOG
        (
        		se10			bigint,
                TOOC_GLB_SE10              BIGINT,
                tooc_bus_vol_12mth     DECIMAL(12,0) NOT NULL
                )

PRIMARY INDEX (TOOC_GLB_SE10)
                ON      COMMIT PRESERVE ROWS;

INSERT INTO vt_chain_vol
                (
                se10,
                TOOC_GLB_SE10,
                tooc_bus_vol_12mth
                )
SELECT
                b.se10,
                b.tooc_glb_se10,
                (case     when COALESCE(a.tooc_bus_vol_12mth,0) >= -99999999999  AND  COALESCE(a.tooc_bus_vol_12mth,0)  < +99999999999 then COALESCE(a.tooc_bus_vol_12mth,0) 
                                when COALESCE(a.tooc_bus_vol_12mth,0)  < -99999999999 then -99999999999 
                                WHEN COALESCE(a.tooc_bus_vol_12mth,0)   > +99999999999 then +99999999999
                END) as tooc_bus_vol_12mth
FROM
                vt_chain_vol_consol  a,
                vt_tooc_othse10             b	
				WHERE a.TOOC_GLB_SE10 = b.TOOC_GLB_SE10
                ;

/****************************** volatile table with values for 20 Next day pay weekly attributes **********************/

CREATE  VOLATILE SET TABLE vt_next_day_pay_wk
,NO FALLBACK
,NO JOURNAL
,CHECKSUM = DEFAULT
,DEFAULT MERGEBLOCKRATIO
,NO LOG
                (
                SE10                                                                                    BIGINT NOT NULL,
                WEIGHT_BUS_AMT                                      DECIMAL(12,0),
                WEIGHT_CREDIT_AMT                                               DECIMAL(12,0),
                WEIGHT_ADJ_AMT                                       DECIMAL(12,0),
                WEIGHT_DBT_ROC_CNT                           DECIMAL(12,3),
                WEIGHT_DBT_SOC_CNT                           DECIMAL(11,3),
                WEIGHT_CRD_ROC_CNT                           DECIMAL(11,3),
                WEIGHT_CRD_SOC_CNT                           DECIMAL(14,3),
                LAST_6MNTH_DBT_SUB_AMT                DECIMAL(12,0),
                LAST_6MNTH_DBT_ROC_CNT                DECIMAL(10,0),
                LAST_6MNTH_AVG_TKT_SZE                  DECIMAL(11,3),
                WEIGHT_DISP_AMT                                      DECIMAL(8,0),
                WEIGHT_DISP_CNT                                       DECIMAL(9,3),
                LAST_6Mnth_DISP_AMT                               DECIMAL(10,0),
                WEIGHT_DSP_GRS_RATIO                       DECIMAL(5,4),
                DISPUTE_OPEN_AMT                                                 DECIMAL(10,0),
                DISPUTE_OPEN_CNT                                                 DECIMAL(6,0),
                MOD_TENURE                                                               DECIMAL(5,0),
                MNTH_SINCE_LAST_SUB                           DECIMAL(5,0),
                SE_CHAIN_TYP                                                             CHAR(1),
                COUNTRY_CD                                                               DECIMAL(3,0),
                tooc_bus_vol_12mth                                                       DECIMAL(12,0),
                CURR_DEBIT_BAL_AMT                              DECIMAL(10,0)
                )
PRIMARY INDEX (se10)
                ON COMMIT PRESERVE ROWS;

INSERT INTO vt_next_day_pay_wk
                (
                SE10                                       ,
                WEIGHT_BUS_AMT                        ,
                WEIGHT_CREDIT_AMT  ,
                WEIGHT_ADJ_AMT                         ,
                WEIGHT_DBT_ROC_CNT              ,
                WEIGHT_DBT_SOC_CNT               ,
                WEIGHT_CRD_ROC_CNT              ,
                WEIGHT_CRD_SOC_CNT              ,
                LAST_6MNTH_DBT_SUB_AMT  ,
                LAST_6MNTH_DBT_ROC_CNT   ,
                LAST_6MNTH_AVG_TKT_SZE     ,
                WEIGHT_DISP_AMT                       ,
                WEIGHT_DISP_CNT                        ,
                LAST_6Mnth_DISP_AMT              ,
                WEIGHT_DSP_GRS_RATIO          ,
                DISPUTE_OPEN_AMT    ,
                DISPUTE_OPEN_CNT     ,
                MOD_TENURE                  ,
                MNTH_SINCE_LAST_SUB             ,
                SE_CHAIN_TYP                 ,
                COUNTRY_CD                    ,
                tooc_bus_vol_12mth     ,
                CURR_DEBIT_BAL_AMT
                )

SELECT distinct

                a.SE10   ,
                COALESCE(a.WEIGHT_BUS_AMT,0)                         ,
                COALESCE(a.WEIGHT_CREDIT_AMT,0)                   ,
                COALESCE(a.WEIGHT_ADJ_AMT,0)                         ,
                COALESCE(a.WEIGHT_DBT_ROC_CNT,0)               ,
                COALESCE(a.WEIGHT_DBT_SOC_CNT,0)               ,
                COALESCE(a.WEIGHT_CRD_ROC_CNT,0)               ,
                COALESCE(a.WEIGHT_CRD_SOC_CNT,0)               ,
                COALESCE(a.LAST_6MNTH_DBT_SUB_AMT,0)   ,
                COALESCE(a.LAST_6MNTH_DBT_ROC_CNT,0)    ,
                COALESCE(a.LAST_6MNTH_AVG_TKT_SZE,0)     ,
                COALESCE(b.WEIGHT_DISP_AMT,0)                       ,
                COALESCE(c.WEIGHT_DISP_CNT,0)                         ,
                COALESCE(b.LAST_6Mnth_DISP_AMT,0)              ,
                COALESCE(f.WEIGHT_DSP_GRS_RATIO,0)            ,
                NULL as DISPUTE_OPEN_AMT                   ,
                NULL as DISPUTE_OPEN_CNT                    ,
                COALESCE(a.MOD_TENURE,0)                                                               ,
                COALESCE(a.MNTH_SINCE_LAST_SUB,0),
                COALESCE(d.SE_CHAIN_TYP,0)             ,
                COALESCE(d.COUNTRY_CD,0)                ,
                COALESCE(g.tooc_bus_vol_12mth,0) as tooc_bus_vol_12mth,
                COALESCE(e.CURR_DEBIT_BAL_AMT,0)

FROM
                vt_se_roc_consolidate a  left outer join vt_se_roc10      b
                on a.se10 = b.se10 left outer join vt_se_roc11    c
                on a.se10 = c.se10 left outer join vt_se_roc12    d
                on a.se10 = d.se10 left outer join vt_se_roc13    e
                on a.se10 = e.se10 left outer join vt_disp_gross_ratio f
                on a.se10 = f.se10 left outer join vt_chain_vol g
                on a.se10 = g.se10

;

update vt_next_day_pay_wk 
set tooc_bus_vol_12mth=10000001
where se10 in(sel se10 from b_se10_toc_mapping where tooc_glb_se10  in (6316383017,1260246103,6317254050,1045136397,4102492154,1045727567,2291935831));

-- Select to cursor

SET v_final_sql = 'SELECT

                SE10                                       ,
                WEIGHT_BUS_AMT                        ,
                WEIGHT_CREDIT_AMT  ,
                WEIGHT_ADJ_AMT                         ,
                WEIGHT_DBT_ROC_CNT              ,
                WEIGHT_DBT_SOC_CNT               ,
                WEIGHT_CRD_ROC_CNT              ,
                WEIGHT_CRD_SOC_CNT              ,
                LAST_6MNTH_DBT_SUB_AMT  ,
                LAST_6MNTH_DBT_ROC_CNT   ,
                LAST_6MNTH_AVG_TKT_SZE     ,
                WEIGHT_DISP_AMT                       ,
                WEIGHT_DISP_CNT                        ,
                LAST_6Mnth_DISP_AMT              ,
                WEIGHT_DSP_GRS_RATIO          ,
                DISPUTE_OPEN_AMT    ,
                DISPUTE_OPEN_CNT     ,
                MOD_TENURE                  ,
                MNTH_SINCE_LAST_SUB             ,
                SE_CHAIN_TYP                 ,
                COUNTRY_CD                    ,
                tooc_bus_vol_12mth     ,
                CURR_DEBIT_BAL_AMT
                FROM vt_next_day_pay_wk' ;

PREPARE s1 FROM v_final_sql;
OPEN cur1;
DEALLOCATE PREPARE s1;

/* --commented the delete statements and moved to separate proc
DELETE FROM b_gms_ndp_roc_stage WHERE us_intl_flg = 'US';
DELETE FROM b_gms_ndp_roc_aggr_mnth WHERE us_intl_flg = 'US';
DELETE FROM b_gms_ndp_roc_sum_tble WHERE us_intl_flg = 'US';
*/

END IF;

END;
