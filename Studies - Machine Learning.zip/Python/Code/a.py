error_codes = {}
words_line = ()
words_list = []

r_file_handle = open("C:\Learn\Python\Code\Data\Crawlee_error_codes.csv", mode='rt', encoding='utf-8')

all_lines = r_file_handle.readlines()
r_file_handle.close()

for line in all_lines:
	error_def = line.split(',')
		
