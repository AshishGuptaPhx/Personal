import sys

def main(r_file, w_file):
    #r_file = "C:\Learn\Python\Code\Data\gms_next_day_pay_us.sql"
    #w_file = "C:\Learn\Python\Code\Data\gms_next_day_pay_us_new.sql"

    r_file_handle = open(r_file, mode='rt', encoding='utf-8')
    w_file_handle = open(w_file, mode='wt', encoding='utf-8')

    all_lines = r_file_handle.readlines()
    prev_line = str(None)
    linenumber = 1

    for line in all_lines:
        printline = "Line Number " + str(linenumber) + ":" + line.strip() + "\n"
        if line.strip() == '' and line.strip() == prev_line.strip():
            pass
        else:
            linenumber += 1
            sys.stdout.write(printline)
            w_file_handle.write(line)

        prev_line = line

    r_file_handle.close()
    w_file_handle.close()
    print("Done")


if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2])