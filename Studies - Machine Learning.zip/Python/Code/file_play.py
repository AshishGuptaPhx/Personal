import sys



def print_file(r_file):
    r_file_handle = open(r_file, mode='rt', encoding='utf-8')

    all_lines = r_file_handle.readlines()
    r_file_handle.close()

    words_line = ()
    words_doc = []

    for line in all_lines:
        words_line = line.split()
        for word in words_line:
            words_doc.append(word)

    words_doc.sort()
    for word in words_doc:
        print(words_doc.index(word), word)


def count_words(r_file):
    #r_file = "C:\Learn\Python\Code\Data\Tanmyaa Expenses 2018006-201808.csv"

    r_file_handle = open(r_file, mode='rt', encoding='utf-8')

    all_lines = r_file_handle.readlines()
    r_file_handle.close()
    words = ()
    word_list = []
    for line in all_lines:
        words = line.split(",")
        word_list.append(words)

    for w in word_list:
        print(type(w[4]), w[4])

    print(word_list)


