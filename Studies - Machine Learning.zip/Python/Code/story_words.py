import sys

def main(r_file):

    r_file_handle = open(r_file, mode='rt', encoding='utf-8')

    all_lines = r_file_handle.readlines()
    r_file_handle.close()

    words_line = ()
    words_doc = []

    for line in all_lines:
        words_line = line.split()
        for word in words_line:
            words_doc.append(word)

   words_doc.sort()
    for word in words_doc:
        print(words_doc.index(word), word)




if __name__ == '__main__':
    main(sys.argv[1])